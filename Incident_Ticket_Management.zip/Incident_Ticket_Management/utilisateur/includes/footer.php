<footer>
        <p>Copyright © 2023 GestionTickets</p>
    </footer>
</body>

</html>