<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Gestion des tickets d'incident</title>
	<link rel="stylesheet" href="../../css/style.css">
	<script src="../../script.js"></script>
</head>

<body>
	<nav>
		<div id="logodiv">
			<!-- <img id="logo" src="images/logo1.png"> -->
		</div>
		<div>
			<ul>
			<div id="logoutdiv">
                    <a id="logoutLink" href="../../logout.php?logout"><img id="logout" src="../../images/se-deconnecter.png"></a>
                </div>
				<li><a href="informations.php">Informations</a></li>
				<li><a href="listTickets.php">Accueil</a></li>
			</ul>
		</div>
	</nav> 